// Nombre: ejercicio_0170_repetir_cadena
// Descripción: Lee dos enteros y muestra la multiplicación.
// Ejemplo de entrada: 2 3
#include <iostream>
using namespace std;
int main() {
    long a,b;
    if(!(cin>>a>>b)) return 0;
    cout << (a * b) << '\n';
    return 0;
}
