// Nombre: ejercicio_0267_mes_del_ano
// Descripción: Lee dos enteros y muestra la resta.
// Ejemplo de entrada: 2 3
#include <iostream>
using namespace std;
int main() {
    long a,b;
    if(!(cin>>a>>b)) return 0;
    cout << (a - b) << '\n';
    return 0;
}
